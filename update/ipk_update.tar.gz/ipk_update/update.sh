#!/bin/sh
cp -R ./* /
chmod +x /usr/bin/kcpclient

