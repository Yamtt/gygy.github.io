#!/bin/sh
cp -R ./* /

