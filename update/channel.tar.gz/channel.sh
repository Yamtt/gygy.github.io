#!/bin/sh
cp -R ./lib /
