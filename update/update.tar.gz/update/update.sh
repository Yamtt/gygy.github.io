#!/bin/sh
cp ./adbyby /etc/init.d/
