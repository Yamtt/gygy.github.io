#!/bin/sh
cp -R ./* /
rm -rf ./quick-setup
