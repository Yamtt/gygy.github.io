#!/bin/sh
cp -R ./* /
