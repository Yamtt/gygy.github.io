﻿/* UTF-8 (with BOM) strings for gargoyle_header_footer */

ghf.title="石像鬼（Gargoyle）路由器管理程序";
ghf.desc="路由器 管理 程序";
ghf.devn="设备名称";
ghf.waits="正在登录<br/>请稍候...";
