﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for themes.sh html elements
 */

thmS.mTheme="主题";
thmS.TMSect="主题管理器";
thmS.Thm="主题";
