﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for login.sh html elements
 */

logS.LSect="登录";
logS.EAdmP="输入管理员密码";
logS.YQot="你的配额";
logS.NQot="整个网络的配额";
logS.CTime="当前日期和时间";
logS.CIP="IP 地址";
logS.CIPs="当前设备连接地址:";

//javascript
logS.passErr="错误：你必须输入密码";
logS.Lging="登录中";
logS.SExp="会话过期";
logS.InvP="无效密码";
logS.LOut="已注销";
logS.Qnam=["总量", "下载", "上传"];
logS.of="的";
logS.fQuo="配额";
logS.husd="已被使用";
logS.qusd="配额已被使用";
