﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for conlimits.sh html elements
 */

connLS.CLSect="连接限制";
connLS.MaxC="最大连接数";
connLS.TTout="TCP超时";
connLS.UTout="UDP超时";
connLS.max="最大";
