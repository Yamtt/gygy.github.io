﻿/* UTF-8 (with BOM) strings for gargoyle_header_footer */

ghf.title="Gargoyle Router Management Utility";
ghf.desc="Router Management Utility";
ghf.devn="Device Name";
ghf.waits="Please Wait While Settings Are Applied";
