﻿/*
 * UTF-8 (with BOM) English-EN text strings for reboot.sh html elements
 */

rbS.RbSect="Reboot";
rbS.SchRb="Scheduled Reboot";
rbS.NoSch="No Scheduled Reboot";
rbS.RbSch="Reboot Scheduled";
rbS.WillR="Router Will Reboot";
rbS.EDay="Every Day";
rbS.EWek="Every Week";
rbS.EMnh="Every Month";
rbS.RDay="Reboot Day";
rbS.RHr="Reboot Hour";

//javascript
rbS.SysR="System Is Now Rebooting";
rbS.Digs="th";
rbS.LD1s="st";
rbS.LD2s="nd";
rbS.LD3s="rd";
rbS.DaysWArr=["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
