﻿/*
 * UTF-8 (with BOM) English-EN text strings for identification.sh html elements
 */

idtS.IdSect="Identification";
idtS.Domn="Domain";
idtS.DevNm="Device Name";
