﻿/*
 * UTF-8 (with BOM) English-EN text strings for printers.sh html elements
 */

prnt.Attch="Attached USB Printers";
prnt.NoPrnt="No USB printers are currently attached to the router.";
prnt.ConnU="is connected via USB.";
prnt.ConnIP="You can connect to your printer on IP";
prnt.JetProto="via HP JetDirect protocol.";
