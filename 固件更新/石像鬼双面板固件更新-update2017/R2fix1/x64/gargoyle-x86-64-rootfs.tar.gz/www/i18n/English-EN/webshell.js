﻿/*
 * UTF-8 (with BOM) English-EN text strings for webshell.sh html elements
 */

webS.Webs="Webshell";
webS.Cmd="Command";
webS.Exe="Execute";
webS.CmdWarn="Do not execute any interactive or endless command!";
