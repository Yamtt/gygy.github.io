﻿/*
 * UTF-8 (with BOM) English-EN text strings for routing.sh html elements
 */

rtgS.mRoutes="Routing";
rtgS.ARSect="Active Routes";
rtgS.SRSect="Static Routes";
rtgS.ASRte="Add Static Route";
rtgS.CSRSect="Current Static Routes";
rtgS.ESSect="Edit Static Route";

//javascript & template
rtgS.Dstn="Destination";
rtgS.DstnM="Destination/Mask";
rtgS.ItfN="Interface(Network)";
rtgS.Itfc="Interface";
rtgS.Ntwk="Network";
rtgS.Gtwy="Gateway";
rtgS.Mtrc="Metric";
rtgS.AErr="Could not add row.";
rtgS.SRErr="Could not update static route.";
