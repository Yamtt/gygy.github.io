Green theme
Based on Light theme
Cezary Jackiewicz <cezary@eko.one.pl>
