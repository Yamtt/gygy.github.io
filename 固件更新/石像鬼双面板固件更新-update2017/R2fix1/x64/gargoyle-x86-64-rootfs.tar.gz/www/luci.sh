#!/usr/bin/haserl
<%
	# This program is copyright © 2008-2013 Eric Bishop and is distributed under the terms of the GNU GPL
	# version 2.0 with a special clarification/exception that permits adapting the program to
	# configure proprietary "back end" software provided that all modifications to the web interface
	# itself remain covered by the GPL.
	# See http://gargoyle-router.com/faq.html#qfoss for more information
	eval $( gargoyle_session_validator -c "$COOKIE_hash" -e "$COOKIE_exp" -a "$HTTP_USER_AGENT" -i "$REMOTE_ADDR" -r "login.sh" -t $(uci get gargoyle.global.session_timeout) -b "$COOKIE_browser_time"  )
	gargoyle_header_footer -h -s "system" -p "luci" -c "internal.css" -j ""
%>

<fieldset>
	<legend class="sectionheader">应用接口</legend>

	<p><span class="contributer">Luci面板 (<a target="_blank" href="http://192.168.1.1:8081">http://192.168.1.1:8081</a>):</span> 访问Luci界面</p>
	<p><span class="contributer">Transmission面板 (<a target="_blank" href="http://192.168.1.1:9091/transmission/web/">http://192.168.1.1:9091/transmission/web/</a>):</span> 访问transmission界面</p>
	<p><span class="contributer">Aria2面板 (<a target="_blank" href="/yaaw/">/yaaw/</a>):</span> 访问Aria2 yaaw界面</p>
	<p><span class="contributer">Aria2webui面板 (<a target="_blank" href="/webui-aria2/">/webui-aria2/</a>):</span> 访问Aria2 webui界面</p>
	<p><span class="contributer">电驴 (<a target="_blank" href="http://192.168.1.1:4711">http://192.168.1.1:4711</a>):</span> 电驴amule,设置才可以访问</p>
	<p><span class="contributer">路由器上的网站 (<a target="_blank" href="http://192.168.1.1:81">http://192.168.1.1:81</a>):</span> 自建网站，设置才可以访问</p>
	<p><span class="contributer">数据库管理 (<a target="_blank" href="http://192.168.1.1:81/phpmyadmin">http://192.168.1.1:81/phpmyadmin</a>):</span> 数据库管理</p>
	<p><span class="contributer">Webdav (<a target="_blank" href="http://192.168.1.1:888/webdav/">http://192.168.1.1:888/webdav/</a>):</span> 访问Webdav地址，设置才可以访问</p>
    <p><span class="contributer">远程迅雷 (<a target="_blank" href="http://yuancheng.xunlei.com/#module=ycxzApp">http://yuancheng.xunlei.com/</a>):</span> 访问远程迅雷地址</p>
</fieldset>

<%
	gargoyle_header_footer -f -s "system" -p "luci"
%>
