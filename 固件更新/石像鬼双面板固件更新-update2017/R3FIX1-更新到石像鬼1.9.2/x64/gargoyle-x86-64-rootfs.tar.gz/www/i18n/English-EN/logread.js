﻿/*
 * UTF-8 (with BOM) English-EN text strings for logread.sh html elements
 */

sylS.SLogs="System Logs";
sylS.Rfsh="Refresh";
sylS.Load="Loading logs...";
