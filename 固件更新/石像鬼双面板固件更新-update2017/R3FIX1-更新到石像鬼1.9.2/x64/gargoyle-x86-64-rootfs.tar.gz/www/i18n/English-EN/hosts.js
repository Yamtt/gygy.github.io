﻿/*
 * UTF-8 (with BOM) English-EN text strings for hosts.sh html elements
 */

hostsStr.mHosts="Connected Hosts";
hostsStr.RefreshR="Refresh Rate";
hostsStr.RInfo="This specifies how frequently data on this page is reloaded";
hostsStr.CurrLeases="Current DHCP Leases";
hostsStr.ConWifiHosts="Connected Wireless Hosts";
hostsStr.ActiveHosts="Hosts With Active Connections";

//javascript
hostsStr.HostIP="Host IP";
hostsStr.HostMAC="Host MAC";
hostsStr.LeaseExp="Lease Expires";
hostsStr.Bitrate="Bitrate";
hostsStr.Signal="Signal";
hostsStr.ActiveConx="Active TCP Cxns";
hostsStr.RecentConx="Recent TCP Cxns";
hostsStr.UDPConx="UDP Cxns";
hostsStr.Band="Band";
