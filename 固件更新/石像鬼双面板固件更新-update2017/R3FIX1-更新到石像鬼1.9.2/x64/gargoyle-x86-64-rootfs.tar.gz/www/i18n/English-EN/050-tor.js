﻿/*
 * UTF-8 (with BOM) English-EN text strings for login hook for tor html elements
 */

torLS.tIP="For your IP, Tor is";
torLS.tEnab="Enable Tor For Your IP";
torLS.tDisa="Disable Tor For Your IP";
torLS.IPErr="ERROR: Your IP was not assigned by the DHCP server and is not configured as a known static IP\n\nTor configuration prohibited";
torLS.EqErr="ERROR: Tor Per-IP matching disabled\n\nTor configuration prohibited";
torLS.EnabMsg="Tor Successfully Disabled for your IP";
torLS.DisbMsg="Tor Successfully Enabled for your IP";
