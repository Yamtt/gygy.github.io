﻿/*
 * UTF-8 (with BOM) English-EN text strings for pptp.sh html elements
 */

pptpS.PCfg="PPTP Configuration";
pptpS.PDis="PPTP Disabled";
pptpS.PClt="PPTP Client";
pptpS.PSts="PPTP Status";
pptpS.PHostNm="PPTP Server";
pptpS.PUser="User Name";
pptpS.PPass="Password";

pptpS.SErr="Server address is not defined";
pptpS.UErr="User name is not defined";
pptpS.PErr="Password is not defined";
pptpS.RunC="Running, Connected";
pptpS.RunNot="Not Running";
pptpS.ReCnt="Reconnect";
