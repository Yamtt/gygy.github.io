﻿/*
 * UTF-8 (with BOM) English-EN text strings for about.sh html elements
 */

initdS.Services="Services";
initdS.NoServ="There is nothing to update!";
initdS.ActServ="Update services";
initdS.ServColumn=['Service', 'Autostart', '', '', ''];
initdS.ServStart="An attempt to start service";
initdS.ServStop="An attempt to stop service";
initdS.ServRestart="An attempt to restart service";
