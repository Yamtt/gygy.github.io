﻿/*
 * UTF-8 (with BOM) English-EN text strings for i18n-firstoot.sh & languages.sh html elements
 */

intS.LMSect="Language manager";

//i18n.js javascript
intS.Lang="Language";
intS.Desc="Description";
intS.Upld="Upload";
intS.UpMsg="Uploading Language File";
intS.Acv8="Activate";
intS.Actv="Active";
intS.Instd="Installed";
