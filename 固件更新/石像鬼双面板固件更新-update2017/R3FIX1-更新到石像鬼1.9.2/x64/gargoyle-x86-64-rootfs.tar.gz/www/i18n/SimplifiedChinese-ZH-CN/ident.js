﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for identification.sh html elements
 */

idtS.IdSect="标识";
idtS.Domn="域名";
idtS.DevNm="设备名称";
