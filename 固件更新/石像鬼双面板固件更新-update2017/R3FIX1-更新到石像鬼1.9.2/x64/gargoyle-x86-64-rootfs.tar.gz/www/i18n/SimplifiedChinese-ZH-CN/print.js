﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for printers.sh html elements
 */

prnt.Attch="已连接的USB打印机";
prnt.NoPrnt="目前没有USB打印机连接到路由器。";
prnt.ConnU="已通过USB连接。";
prnt.ConnIP="你可以通过IP连接到你的打印机";
prnt.JetProto="已通过惠普JetDirect协议连接。";
