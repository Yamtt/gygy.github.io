﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for webshell.sh html elements
 */

webS.Webs="Webshell";
webS.Cmd="命令";
webS.Exe="执行";
webS.CmdWarn="不要执行任何交互式或无休止的命令！";
