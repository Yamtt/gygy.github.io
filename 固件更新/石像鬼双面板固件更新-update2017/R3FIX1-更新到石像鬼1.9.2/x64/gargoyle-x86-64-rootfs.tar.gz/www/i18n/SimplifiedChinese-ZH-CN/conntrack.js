﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for contrack.sh html elements
 */

connTS.CCSect="当前连接";
connTS.RRate="刷新速度";
connTS.BUnt="流量单位";
connTS.AtMxd="自动（混合）";
connTS.CnWarn="本地主机和路由器之间的连接不会被显示。";
connTS.PrNm="协议";
connTS.WLNm="WAN/LAN主机";
connTS.UDNm="上传/下载字节数";
connTS.QSNm="QoS上传/下载";
connTS.LPNm="L7协议";
