﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for i18n-firstoot.sh & languages.sh html elements
 */

intS.LMSect="语言管理器";

//i18n.js javascript
intS.Lang="语言";
intS.Desc="描述";
intS.Upld="上传";
intS.UpMsg="正在上传语言文件";
intS.Acv8="激活";
intS.Actv="生效";
intS.Instd="已安装";
