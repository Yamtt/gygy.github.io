﻿/*
 * UTF-8 (with BOM) English-EN text strings for themes.sh html elements
 */

thmS.mTheme="Themes";
thmS.TMSect="Themes manager";
thmS.Thm="Theme";
