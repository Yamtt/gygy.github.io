﻿/*
 * UTF-8 (with BOM) English-EN text strings for firstboot.sh html elements
 */

fbS.ISSect="Initial Settings";
fbS.npass="Enter a new password now";
fbS.NPass="New Password";
fbS.Stz="Select your timezone";
fbS.Sla="Select Language";
fbS.SSet="Save Settings";
fbS.ULngF="Upload Language File";

//javascript
fbS.nopsErr="ERROR: You must specify a password";
fbS.pseqErr="ERROR: Passwords do not match";
