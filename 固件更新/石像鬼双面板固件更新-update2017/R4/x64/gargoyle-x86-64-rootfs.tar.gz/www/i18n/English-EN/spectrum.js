﻿/*
 * UTF-8 (with BOM) English-EN text strings for spectrum_analyser.sh html elements
 */

spectrum.Noscan="Scan returned no results!\nRefresh the page to try again, or change bands.";
spectrum.Analyser="Spectrum Analyser";
spectrum.SSID="SSID";
spectrum.BSSID="BSSID";
spectrum.Channel="Channel";
spectrum.Width="Width";
spectrum.Mode="Mode";
spectrum.Signal="Signal";

