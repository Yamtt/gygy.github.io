﻿/*
 * UTF-8 (with BOM) English-EN text strings for webshell.sh html elements
 */

dlna.DLNA="DLNA";
dlna.DLNAEn="Enable DLNA";
dlna.StatDLNA="DLNA Status";
dlna.RescanDLNA="Rescan media";
dlna.DLNASName="Server name";
dlna.DLNAStr="Strict DLNA";
dlna.DLNAMType="Media type";
dlna.DLNAAll="All";
dlna.DLNAA="Audio";
dlna.DLNAV="Video";
dlna.DLNAI="Image";
dlna.DLNADrive="Drive";
dlna.DLNAMFolder="Media folder";
dlna.DLNAFolders="Folders list";
dlna.RootD="Root Disk";

dlna.Totl="Total";
dlna.Free="Free";
dlna.Drv="Drive";
dlna.Dir="Folder";

dlna.ERRAllrAdd="This folder is already added";
dlna.ERRSName="DLNA server name can not be empty";
