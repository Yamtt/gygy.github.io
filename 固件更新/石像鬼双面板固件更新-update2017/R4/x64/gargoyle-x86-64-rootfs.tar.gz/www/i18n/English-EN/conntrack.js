﻿/*
 * UTF-8 (with BOM) English-EN text strings for contrack.sh html elements
 */

connTS.CCSect="Current Connections";
connTS.RRate="Refresh Rate";
connTS.BUnt="Bandwidth Units";
connTS.AtMxd="Auto (Mixed)";
connTS.CnWarn="Connections between local hosts and the router are not displayed.";
connTS.PrNm="Proto";
connTS.WLNm="LAN Host/WAN Host";
connTS.UDNm="Bytes Up/Down";
connTS.QSNm="QoS Up/Down";
connTS.LPNm="L7 Proto";
