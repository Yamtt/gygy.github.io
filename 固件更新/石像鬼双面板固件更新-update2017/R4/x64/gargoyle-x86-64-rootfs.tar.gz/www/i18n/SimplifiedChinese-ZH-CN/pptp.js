﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for pptp.sh html elements
 */

pptpS.PCfg="PPTP配置";
pptpS.PDis="禁用PPTP";
pptpS.PClt="PPTP客户端模式";
pptpS.PSts="PPTP状态";
pptpS.PHostNm="PPTP服务器地址";
pptpS.PUser="用户名";
pptpS.PPass="密码";

pptpS.SErr="服务器地址未定义";
pptpS.UErr="用户名未定义";
pptpS.PErr="密码未定义";
pptpS.RunC="运行中，已连接";
pptpS.RunNot="未运行";
pptpS.ReCnt="重新连接";
