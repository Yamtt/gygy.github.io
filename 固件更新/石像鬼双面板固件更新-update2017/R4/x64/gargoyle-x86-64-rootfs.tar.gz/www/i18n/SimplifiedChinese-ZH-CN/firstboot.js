﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for firstboot.sh html elements
 */

fbS.ISSect="初始设置";
fbS.npass="输入新密码";
fbS.NPass="新密码";
fbS.Stz="选择你的时区";
fbS.Sla="选择语言";
fbS.SSet="保存设置";
fbS.ULngF="上传语言文件";

//javascript
fbS.nopsErr="错误：你必须设置一个密码";
fbS.pseqErr="错误：两次输入的密码不相同";
