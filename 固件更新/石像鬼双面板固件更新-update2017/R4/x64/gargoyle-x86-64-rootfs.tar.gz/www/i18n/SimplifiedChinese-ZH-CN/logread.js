﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for logread.sh html elements
 */

sylS.SLogs="系统日志";
sylS.Rfsh="刷新";
sylS.Load="正在读取日志";
