﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for routing.sh html elements
 */

rtgS.mRoutes="路由设置";
rtgS.ARSect="活动的路由";
rtgS.SRSect="静态路由";
rtgS.ASRte="添加静态路由";
rtgS.CSRSect="当前静态路由";
rtgS.ESSect="编辑静态路由";

//javascript & template
rtgS.Dstn="目标网络";
rtgS.DstnM="目标网络/掩码";
rtgS.ItfN="接口（网络）";
rtgS.Itfc="接口";
rtgS.Ntwk="网络";
rtgS.Gtwy="网关";
rtgS.Mtrc="度量";
rtgS.AErr="无法添加该行。";
rtgS.SRErr="无法更新静态路由。";
