﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for webmon.sh html elements
 */

webmS.mWMon="Web监视";
webmS.PrSect="Web监视首选项";
webmS.EMon="启用Web使用监视";
webmS.NumSt="保存网址记录的数量";
webmS.NumSr="保存搜索操作的数量";
webmS.MnAH="监视所有主机";
webmS.MnOnly="仅监视以下主机";
webmS.MnExcl="不监控以下主机";
webmS.SpcIP="指定IP或IP范围";
webmS.RctSt="最近浏览过的网站";
webmS.RctSr="最近使用过的搜索";
webmS.DlWD="下载Web使用情况数据";
webmS.cmsep="数据格式使用逗号分隔（CSV文件）";
webmS.dForm="[最后浏览时间],[本地IP],[浏览的域名/搜索关键字]";
webmS.VSit="浏览过的网站";
webmS.SRqst="使用过的搜索";
webmS.dCol=['本地主机', '最后访问时间', '网站'];
webmS.sCol=['本地主机', '最后访问时间', '搜索关键字'];
