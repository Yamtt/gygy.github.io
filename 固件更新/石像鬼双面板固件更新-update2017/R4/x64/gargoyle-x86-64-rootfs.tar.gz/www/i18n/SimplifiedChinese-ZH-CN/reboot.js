﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for reboot.sh html elements
 */

rbS.RbSect="重启";
rbS.SchRb="计划性重启";
rbS.NoSch="不作计划性重启";
rbS.RbSch="重启计划";
rbS.WillR="路由器将重启";
rbS.EDay="每天";
rbS.EWek="每星期";
rbS.EMnh="每月";
rbS.RDay="重启日";
rbS.RHr="重启时间";

//javascript
rbS.SysR="系统正在重启";
rbS.Digs="th";
rbS.LD1s="st";
rbS.LD2s="nd";
rbS.LD3s="rd";
rbS.DaysWArr=["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
