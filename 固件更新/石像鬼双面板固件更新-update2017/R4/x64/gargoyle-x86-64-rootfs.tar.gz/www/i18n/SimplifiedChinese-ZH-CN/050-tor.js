﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for login hook for tor html elements
 */

torLS.tIP="你IP的Tor状态是";
torLS.tEnab="为你的IP启用Tor";
torLS.tDisa="为你的IP禁用Tor";
torLS.IPErr="错误：你的IP并非由DHCP服务器分配并且没有配置为一个已知的静态IP\n\nTor配置被禁止";
torLS.EqErr="错误：Tor Per-IP匹配失败\n\nTor配置被禁止";
torLS.EnabMsg="你的IP已成功禁用Tor";
torLS.DisbMsg="你的IP已成功启用Tor";
