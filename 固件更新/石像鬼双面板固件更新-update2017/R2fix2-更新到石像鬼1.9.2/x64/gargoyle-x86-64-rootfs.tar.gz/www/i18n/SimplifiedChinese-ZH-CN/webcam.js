﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for webcam.sh html elements
 */

WebC.WebC="网络摄像头";
WebC.NoWebC="未检测到网络摄像头";
WebC.EnWebC="启用网络摄像头";
WebC.EnRAWebC="启用远程访问";
WebC.WebCDev="设备";
WebC.WebCRes="分辨率";
WebC.WebCFPS="每秒帧速(FPS)";
WebC.WebCYUYV="使用YUYV格式";
WebC.WebCPort="端口";
WebC.WebCUName="用户名";
WebC.WebCPass="密码";
WebC.PrevWebC="预览";
WebC.WebCOpt="选项";

WebC.ErrorPortWebC="网络摄像头端口号冲突";
WebC.AvelAtWebC="网络摄像头可用";
