﻿/*
 * UTF-8 (with BOM) English-EN text strings for login.sh html elements
 */

logS.LSect="Login";
logS.EAdmP="Enter Admin Password";
logS.YQot="Your Quota";
logS.NQot="Entire Network Quota";
logS.CTime="Current Date &amp; Time";
logS.CIP="IP Address";
logS.CIPs="You are currently connected from:";

//javascript
logS.passErr="ERROR: You must enter a password";
logS.Lging="Logging In";
logS.SExp="Session Expired";
logS.InvP="Invalid Password";
logS.LOut="Logged Out";
logS.Qnam=["total up+down", "download", "upload" ];
logS.of="of";
logS.fQuo="for Quota";
logS.husd="has been used";
logS.qusd="quota has been used";
