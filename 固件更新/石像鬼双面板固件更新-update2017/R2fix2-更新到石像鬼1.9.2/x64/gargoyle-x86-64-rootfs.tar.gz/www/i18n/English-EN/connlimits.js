﻿/*
 * UTF-8 (with BOM) English-EN text strings for conlimits.sh html elements
 */

connLS.CLSect="Connection Limits";
connLS.MaxC="Max Connections";
connLS.TTout="TCP Timeout";
connLS.UTout="UDP Timeout";
connLS.max="max";
