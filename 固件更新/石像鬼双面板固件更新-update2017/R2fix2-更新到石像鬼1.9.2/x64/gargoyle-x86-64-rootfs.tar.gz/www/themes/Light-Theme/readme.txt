Light theme r96
http://www.gargoyle-router.com/phpbb/viewtopic.php?f=7&t=1175
