angular
.module('webui.services.constants',  [])
.constant('$name', 'webui-aria2')
.constant('$globalTimeout', 1000)

