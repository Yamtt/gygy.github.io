﻿/*
 * UTF-8 (with BOM) English-EN text strings for ping_watchdog.sh html elements
 */

pingS.Pdog="Ping Watchdog";
pingS.EnbP="Enable Ping Watchdog";
pingS.PgIP="IP Address To Ping";
pingS.IPAd="IP Address";
pingS.Intv="Ping Interval";
pingS.StDly="Startup Delay";
pingS.FlCnt="Failure ping count";
pingS.Actn="Action";
pingS.WRcon="WAN Reconnect";
pingS.Rbot="Reboot";
pingS.Rscp="Run custom script";
pingS.Scpt="Script";

//javascript
pingS.ScptErr="You must add the script to execute";
