﻿/*
 * UTF-8 (with BOM) English-EN text strings for logread.sh html elements
 */

WebC.WebC="Webcam";
WebC.NoWebC="No USB Webcam Detected";
WebC.EnWebC="Enable Webcam";
WebC.EnRAWebC="Enable Remote Access";
WebC.WebCDev="Device";
WebC.WebCRes="Resolution";
WebC.WebCFPS="Frames Per Second (FPS)";
WebC.WebCYUYV="Use YUYV format";
WebC.WebCPort="Port";
WebC.WebCUName="User Name";
WebC.WebCPass="Password";
WebC.PrevWebC="Preview";
WebC.WebCOpt="optional";

WebC.ErrorPortWebC="Webcam server port conflicts with ";
WebC.AvelAtWebC="Webcam is available at ";
