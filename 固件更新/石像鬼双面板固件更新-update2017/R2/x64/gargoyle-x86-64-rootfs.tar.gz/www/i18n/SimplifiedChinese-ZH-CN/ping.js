﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for ping_watchdog.sh html elements
 */

pingS.Pdog="Ping守护进程";
pingS.EnbP="启用Ping守护进程";
pingS.PgIP="需要Ping的IP地址";
pingS.IPAd="IP地址";
pingS.Intv="Ping间隔";
pingS.StDly="启动延迟";
pingS.FlCnt="Ping失败次数";
pingS.Actn="动作";
pingS.WRcon="WAN端重新连接";
pingS.Rbot="重启";
pingS.Rscp="运行自定义脚本";
pingS.Scpt="脚本";

//javascript
pingS.ScptErr="你必须添加要执行的脚本";
