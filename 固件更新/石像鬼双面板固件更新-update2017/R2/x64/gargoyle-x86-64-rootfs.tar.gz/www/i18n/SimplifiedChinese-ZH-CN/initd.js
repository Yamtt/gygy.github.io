﻿/*
 * UTF-8 (with BOM) Simplified Chinese ZH-CN text strings for initd.sh html elements
 */

initdS.Services="服务";
initdS.NoServ="无任何更新";
initdS.ActServ="更新服务";
initdS.ServColumn=['服务', '开机启动', '', '', ''];
initdS.ServStart="正在尝试启动服务";
initdS.ServStop="正在尝试停止服务";
initdS.ServRestart="正在尝试重启服务";
