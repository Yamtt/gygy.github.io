﻿/*
 * UTF-8 (with BOM) English-EN text strings for spectrum_analyser.sh html elements
 */

spectrum.Noscan="扫描没有返回任何结果！\n刷新页面再次尝试，或者改变频段。";
spectrum.Analyser="频谱分析仪";
spectrum.SSID="SSID";
spectrum.BSSID="BSSID";
spectrum.Channel="渠道";
spectrum.Width="宽度";
spectrum.Mode="模式";
spectrum.Signal="信号";

